package com.example.thread_handler;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView tv1, tv2;
    Button btn1, btn2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv1 = findViewById(R.id.tv1);
        tv2 = findViewById(R.id.tv2);
        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Thread실행!  1.Thread객체 생성  2.start매서드 호출
                TimeTread th1 = new TimeTread(tv1);                                            //ⓐ
                th1.start();
             }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TimeTread th2 = new TimeTread(tv2);
                th2.start();
            }
        });

    }

    /*****************************************************************************************/

    /*핸들러만들기(MainThread 와 연결해주는 역할)*/
    Handler handler = new Handler(Looper.getMainLooper()){                                      //ⓔ
        @Override   //..
        public void handleMessage(@NonNull Message msg) {
            ((TextView)(msg.obj)).setText(msg.arg1+"");                      //setText문자열로 표시
            //textview로 다운케스팅 (msg.obj)1번 -> setText
        }
    };

    /*Tread설계(InnerClass로 tread를 설계)*/
    class TimeTread extends Thread {                                                            //ⓑ
                            //1. start메소드 실행(onCreate에서 동작시킬때만 사용) -> override는 run만
                            //2. run메소드 실행
                            //3. destroy 메소드 실행(사라질때)

        private TextView tv;       //(thread객체를 생성시)값을 바꿔야 하는 TextView전달            //ⓒ
        TimeTread(TextView tv){
            this.tv = tv;
        }

        @Override
        public void run() {                                                                     //ⓓ
            /*1~10까지 숫자세기(1초에 한번씩)*/
            for (int i=1; i<=10; i++){
                //Handler보내는 방식: Message
                Message msg = new Message();        // Message 3개의 변수(1. Object obj, 2. int arg1, 3. int arg2)
                msg.arg1 = i;
                msg.obj = tv;
                handler.sendMessage(msg);           //..

                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {      //오류확인: alt+enter
                    e.printStackTrace();                //try_catch: try실행하다 예외발생시, 다 건너뛰고 catch로 넘어감
                                                        //tread종료시 사용
                }
            }
        }//run();
    }
}

