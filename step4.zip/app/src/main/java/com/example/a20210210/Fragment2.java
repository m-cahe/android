package com.example.a20210210;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;

import android.os.Environment;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;

public class Fragment2 extends Fragment {

    File file;
    int CALL_CAMERA = 1;
    ImageView img;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View fragment = inflater.inflate(R.layout.fragment_2, container, false);
        Button btn = fragment.findViewById(R.id.btn_camera);
        img = fragment.findViewById(R.id.imageView);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(), "camera-click", Toast.LENGTH_SHORT).show();
                //contantProvider도움 필요

                if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED){
                    ActivityCompat.requestPermissions(getActivity(),
                            new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.READ_EXTERNAL_STORAGE},
                            0);
                }

                takePicture();

            }
        });
        return fragment;
    }
    /*
    1. takePicture 메소드 생성
    2. xml폴더 만들어서 external.xtml파일 생성
    3. Manifest.xml파일 열어서 권한 부여
    4. Manifest.xml파일에 contentProvider정의하기
    5. 권한요청 Dialog띄우기
    */

    /*사진찍는 부분*/
    public void takePicture(){
        //저장할 파일 생성
        if(file==null){
            String fileName = "image.jpg";
            File dir = Environment.getExternalStorageDirectory();  //현재기기의 외부저장소 경로 지정
            file = new File(dir, fileName);                        //해당 경로에 fileName으로 저장하겠다
        }

        //방금 지정한 dir에 바로 저장할 수 없음(보안상 이유)!
        //ContentProvider라고 하는 Android 컴포넌트의 도움을 받아 저장소에 저장
        Uri uri = FileProvider.getUriForFile(getContext(),"org.techtown.capture.intent.fileprovider", file);

        //카메라 실행!
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
        if (intent.resolveActivity(getActivity().getPackageManager())!=null){
            startActivityForResult(intent, CALL_CAMERA);
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode == getActivity().RESULT_OK){
            if (requestCode == CALL_CAMERA){
                BitmapFactory.Options options = new BitmapFactory.Options();
                Bitmap bit = BitmapFactory.decodeFile(file.getAbsolutePath(), options);
                img.setImageBitmap(bit);
            }
        }
    }
}