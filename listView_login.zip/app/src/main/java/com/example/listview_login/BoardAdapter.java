package com.example.listview_login;

import android.content.Context;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

//android에서 Adapter을 custom할 수 있도록 Adapter형태 제공 => BaseAdapter상속
public class BoardAdapter extends BaseAdapter { //alt+enter ->implement method

    // 1. Adapter 내에 Field(전역변수)를 정의

    private Context co;               //activity화면정보
    private int layout;               //항목이 될 뷰(boardlist)의 id값 : id는 int형
    private ArrayList<String> data;   //보여줄 데이터

    private LayoutInflater inflater;

    //1. Adapter가 하는 일
    /*항목 디자인 Layout의 id(int)와 data(ArrayList)를 전달받아서
      data의 개수만큼 Layout을 복사하여
      data를 Layout에 표현*/

    //2.항목 디자인 layout을 App에 띄움 => inflater(대표적으로 findViewById, setContentView)
        /*그런데 inflater는 Activity만 할 수 있음, Adapter는 할 수 있을까요?
          그래서 Activity의 정보인 Context를 전달받아서 inflate기능만 추출해야 한다*/

    //[1].생성자 메소드를 통해 Field에 정의된 변수를 전달받기
            /* 객체 생성할 때 호출되는 메소드! (주로 Field 초기화(변수에 최초로 값을 지정)할 때 사용)*/
                // [alt+insert] => constructor => 3개 필드 가져온다
                public BoardAdapter(Context co, int layout, ArrayList<String> data) {
                    this.co = co;
                    this.layout = layout;
                    this.data = data;

                    this.inflater = (LayoutInflater) co.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                }

    @Override
    public int getCount() {                 //전체 ListView 항목의 개수를 리턴!
        return data.size();
    }

    @Override
    public Object getItem(int position) {   //position(매개변수) 번째의 데이터를 리턴!
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {   //position(매개변수) 번째의 id를 리턴
        return position;
    }


    @Override                               //***position번째의 항목을 만드는 method /**position번째의 항먹을 만드는 method -> inflate작업
    public View getView(int position, View convertView, ViewGroup parent) {
                    //항목을 만들때마다 inflate하게 되면 폰이 버벅
                    if(convertView == null){
                        convertView = inflater.inflate(layout, parent, false);
                    }

        TextView tv = convertView.findViewById(R.id.tv_title);
        tv.setText(data.get(position));

        /*삭제버튼 클릭
        1. 버튼의 ID로 findViewByid
        */
        Button btn = convertView.findViewById(R.id.btn_delete);
        btn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                data.remove(position);
                notifyDataSetChanged();
            }
        });


        return convertView;
    }
}
