package com.example.listview_login;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    TextView logBefore;
    Button wirteBtn;
    Button logBtn;

    ListView lv;
    ArrayList<String> board_data = new ArrayList<>();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lv = findViewById(R.id.listView);
        wirteBtn = findViewById(R.id.wirteBtn);
        logBtn = findViewById(R.id.LogBtn);
        logBefore = findViewById(R.id.logBefore);

        board_data.add("1. 하하");
        board_data.add("2. 호호");
        board_data.add("3. 헤헤");
        board_data.add("4. 후");
        board_data.add("5. 히히");

        BoardAdapter adapter = new BoardAdapter(MainActivity.this, R.layout.boardlist, board_data);
        lv.setAdapter(adapter);

        logBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SubActivity.class);
                startActivityForResult(intent, 0);
            }
        });//logBtn
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            if (requestCode == 0){
            String welcome = data.getStringExtra("ID");
            logBefore.setText(welcome +"님 환영합니다");}
        }else {
            Toast.makeText(MainActivity.this, "실패", Toast.LENGTH_SHORT).show();
        }
    }//getResult

}