package com.example.a20210122;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity3 extends AppCompatActivity {

    int[] imgs = {R.drawable.dice1, R.drawable.dice2, R.drawable.dice3, R.drawable.dice4, R.drawable.dice5, R.drawable.dice6};

    Random rd = new Random();

    private ImageView left;
    private ImageView right;

    int num1;
    int num2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        left = findViewById(R.id.left);
        right = findViewById(R.id.right);
    }

    public void change(View view){

        num1 = rd.nextInt(6);
        num2 = rd.nextInt(6);
        Log.v("check","num1");

        left.setImageResource(imgs[num1]);
        right.setImageResource(imgs[num2]);


    }

}