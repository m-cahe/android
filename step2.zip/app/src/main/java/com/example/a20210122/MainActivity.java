package com.example.a20210122;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private ImageView imageview;
    int cnt = 0;

    int[] img = {R.drawable.conn, R.drawable.appich, R.drawable.rion, R.drawable.neo, R.drawable.prodo};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageview = findViewById(R.id.imageView);
    }


    public void pre(View view) {

        if (cnt != 0) {
            cnt--;
            imageview.setImageResource(img[cnt]);
        }
        else{
            Toast.makeText(this, "첫화면입니다", Toast.LENGTH_SHORT).show();
        }
    }

    public void next(View view) {

        if (cnt < img.length-1) {
            cnt++;
            imageview.setImageResource(img[cnt]);
        } else {
            Toast.makeText(this, "끝입니다", Toast.LENGTH_SHORT).show();
        }
    }


}
