package com.example.a20210122;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class SubActivity extends AppCompatActivity {

    TextView tv_result;
    Button btn_pro;
    Button send_btn;
    ListView lv;

    EditText edit_msg;
    //[톡리스트 만드는 법]
    //1. 톡 데이터를 만들어줍니다      -> arrayList사용
    //2. 톡 하나를 디자인합니다
    //3. Adaptor를 만들어서 (디자인+톡데이터 합쳐주기)
    //4. Adaptor를 ListView에 부착
    
    //ArrayList 생성하고 카톡 5개 추가
    ArrayList<TalkVO> chat_window = new ArrayList<>();
    //TextView chat_list;
    TalkAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main7);

            btn_pro = findViewById(R.id.btn_pro);
            tv_result = findViewById(R.id.tv_result);
           // chat_list = findViewById(R.id.chat_list);
            send_btn = findViewById(R.id.send_btn);
            edit_msg = findViewById(R.id.edit_msg);
            
            /*GoogleCloud Server - FireBase연동해보기*/
            FirebaseDatabase database = FirebaseDatabase.getInstance("https://talkmake-99984-default-rtdb.firebaseio.com/");
            DatabaseReference ref = database.getReference("msg");

            /*intent가져오기:getIntent*/
            String input = getIntent().getStringExtra("input_id");
                    tv_result.setText(input + " 님 환영합니다");

                    ref.addChildEventListener(new ChildEventListener() {  //하위 경로에 무슨일이 생겼을 때를 감지
                        @Override
                        public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                            //자식이 추가되었을 때를 감지  (dataSnapshot:새로 추가된)
                            TalkVO temp = dataSnapshot.getValue(TalkVO.class);
                            chat_window.add(temp);
                            adapter.notifyDataSetChanged();
                        }

                        @Override
                        public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                            //자식이 변경되었을 때를 감지
                        }

                        @Override
                        public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

                        }

                        @Override
                        public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                            //자식이 이동되었을 때를 감지
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                            //에러가 발생해서 제대로 동작못할 때(예외처리)
                        }
                    });


                    //채팅방 생성: chat_window
                    /*chat_window.add(new TalkVO(R.drawable.appich, "어피치","안녕!","12:50"));
                    chat_window.add(new TalkVO(R.drawable.conn, "콘","헬프미","13:40"));
                    chat_window.add(new TalkVO(R.drawable.neo, "네오","(사진)","17:50"));
                    */

            //1.현재 Activity정보
            //2.리스트뷰의 항목이 될 디자인 Layout
            //3.리스트뷰에 넣어줄 데이터
            //adapter = new ArrayAdapter<String>(SubActivity.this, R.layout.simplelist, chat_window);
                    //ArrayAdaptersms textVie단독으로만 사용가능, baseAdapter상속받은 adapter설계                                                                   //디자인 + 내용
            adapter = new TalkAdapter(SubActivity.this, R.layout.talklayout, chat_window);
            //chat_list큰 list레이아웃
            lv = findViewById(R.id.chat_list);
            lv.setAdapter(adapter);

                //Onclick
                    btn_pro.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            finish();
                            //ntent intent = new Intent(SubActivity.this, MainActivity6.class);
                            //startActivity(intent);
                        }
                    });

                send_btn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                                //1. edit_msg에 있는 문자 가져오기

                                String msg = edit_msg.getText().toString();
                                long time = System.currentTimeMillis();                     //currentTimeMillis()
                                SimpleDateFormat sdf = new SimpleDateFormat("HH:mm"); //HH:14시, hh:02시
                                String data = sdf.format(new Date(time));

                            //3. firebase로 데이터 전송하기!
                            ref.push().setValue(new TalkVO(R.drawable.prodo, input, msg, data));

                            //3. adapter새로고침
                                adapter.notifyDataSetChanged();
                                edit_msg.setText("");
                        }
                    });

    }
}