package com.example.a20210122;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

//1. findViewbyId
//2. onClick(EventListner)를 set합니다
//3. 버튼 누르면 subActivity로 이동

public class MainActivity6 extends AppCompatActivity {

    String id = "aaa";
    String pw = "1234";

    Button btn_next;
    private long Backtime = 0;
    EditText edit_id;
    EditText edit_pw;

    //listview
    ListView chat_list;
    ArrayList<TalkVO[]> data = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);

        btn_next = findViewById(R.id.btn_next);                     //1
        edit_id = findViewById(R.id.edit_id);
        edit_pw = findViewById(R.id.edit_pw);

        chat_list = findViewById(R.id.chat_list);

        btn_next.setOnClickListener(new View.OnClickListener() {    //2
            @Override
            public void onClick(View v) {
                //Toast.makeText(MainActivity6.this,"click", Toast.LENGTH_SHORT).show();
                String input_id = edit_id.getText().toString();
                String input_pw = edit_pw.getText().toString();

                //클릭시, 다음페이지로 이동
                //3. intent준비(출발 Activity) //intetn실행
                //Intent intent = new Intent(MainActivity6.this, SubActivity.class);

                //클릭시, Text 다음페이지로 보내기
                //intent.putExtra("input",input);
                //startActivity(intent);

                //클릭시, id와 pw 확인해서 보내기
                if (input_id.equals(id) && input_pw.equals(pw)) {
                    Toast.makeText(MainActivity6.this, "접속성공", Toast.LENGTH_SHORT).show();

                        /*intent보내기*/
                        Intent intent = new Intent(MainActivity6.this, SubActivity.class);
                        intent.putExtra("input_id", input_id);
                        startActivity(intent);

                } else {
                    Toast.makeText(MainActivity6.this, "ID, PW입력 실패", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }//onCreate


    //뒤로가기 2번클릭시 종료
    @Override
    public void onBackPressed() {
        long curTime = System.currentTimeMillis();
        long gapTime = curTime - Backtime;

        if (0 <= gapTime && 2000 >= gapTime) {
            super.onBackPressed();
        } else {
            Backtime = curTime;
            Toast.makeText(MainActivity6.this, "2번 누르면 종료됩니다", Toast.LENGTH_SHORT).show();
        }

    }//onBackPressed
}