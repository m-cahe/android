package com.example.a20210122;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class home_work extends AppCompatActivity {

    int[] img = {R.drawable.dice1, R.drawable.dice2, R.drawable.dice3, R.drawable.dice4, R.drawable.dice5, R.drawable.dice6};

    Random rd = new Random();
    ImageView left_img;
    ImageView right_img;

    TextView text_num;
    TextView winner;

    int left_score = 0;
    int right_score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        left_img = findViewById(R.id.left_img);
        right_img = findViewById(R.id.right_img);
        text_num = findViewById(R.id.text_num);
        winner = findViewById(R.id.winner);
    }

    public void click(View view){
        int num1 = rd.nextInt(6);
        int num2 = rd.nextInt(6);

       left_img.setImageResource(img[num1]);
       right_img.setImageResource(img[num2]);



 //내가 한거얌
       if (num1==num2){
           winner.setText("무승부");
       }
       else if (num1>num2){
           winner.setText("Left 승!");
           left_score++;
       }
       else{
           winner.setText("Right 승!");
           right_score++;
       }

        text_num.setText(left_score + " : " + right_score);


    }
}

//기영's

/*
       if(num1==num2){
           Toast.makeText(this,"비겼습니다",Toast.LENGTH_SHORT).show();
       }else{
           boolean check = true;

           check = num1>num2?true:false;
           if(check){
               left_score++;
               winner.setText("Left 승!");
           }
           else{
               right_score++;
               winner.setText("Right 승!");
           }
           text_num.setText(String.valueOf(left_score + " : " + right_score));
       }
*/