package com.example.a20210122;

public class TalkVO {

    //설계할때 만들어야 되는 거!
        /*1. Field
        * 2. 생성자 메소드
        * 3. get.set(get만)
        * 4. +toString*/
    private int imgID;
    private String name;
    private String msg;
    private String time;

    public TalkVO() {
    }

    public TalkVO(int image, String name, String msg, String time) {
        this.imgID = image;
        this.name = name;
        this.msg = msg;
        this.time = time;
    }

    public int getImage() {
        return imgID;
    }

    public String getName() {
        return name;
    }

    public String getMsg() {
        return msg;
    }

    public String getTime() {
        return time;
    }
}
