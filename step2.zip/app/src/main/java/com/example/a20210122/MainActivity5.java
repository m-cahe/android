package com.example.a20210122;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity5 extends AppCompatActivity{

   Random rd = new Random();

   int[] nums = new int[25];
   Button[] buttons = new Button[25];

   int cnt = 1;
    Chronometer ch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);

        ch = findViewById(R.id.textView2);
        ch.start();

        for (int i = 0; i < 25; i++) {
            nums[i] = i + 1;
        }


        for (int i = 0; i < buttons.length; i++) {
            int btnID = getResources().getIdentifier("button" + (i + 1), "id", getPackageName());
            //문자열(변수명)로 view의 id값(추소값 찾아오는 메소드)
            buttons[i] = findViewById(btnID);
            System.out.println("동준바보");

            //버튼 잘찾아와졌는지 확인위해, 버튼 색깔 바꾸기 시작
            buttons[i].setBackgroundColor(Color.parseColor("#F0268C"));

            buttons[i].setText(nums[i] + "");
            buttons[i].setTextSize(20);

            
            //java코드로 click이벤트 설정
            buttons[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                                    //view:현재 클릭이 발생한 view를 상징

                    //Button button = (button) v
                    // View를 button으로 다운케스팅(or ((Button)v).getText)
                                                        //첫번째로 (Button)을 적어 다운케스팅을 해야한다

                    String button_int = ((Button)v).getText().toString();

                            if (button_int.equals(cnt+"")){
                                v.setVisibility(View.INVISIBLE);
                                cnt++;
                                if(cnt == 26) {
                                    ch.stop();
                                }

                                }
                              }

            });
        }

            //확인과정(중복 랜덤값 있는지)}

        //1번 방법
        /*
            for (int i=0; i<nums.length;i++){
            randomValue[i] = rd.nextInt(nums.length)+1;

                for (int j = 0; j < i; j++) {
                    if (randomValue[i] == randomValue[j]) {
                        i--;
                    }
                }
            }

            for (int i = 0; i < nums.length; i++) {
                buttons[i].setText(randomValue[i]);
            }
            */

        //2번 방법
        ArrayList<Integer> card = new ArrayList<>();
        for (int i = 0; i<25;i++){
            card.add(i+1);
        }

        Random rd = new Random();
        for (int i=0; i<nums.length; i++){
            int num = rd.nextInt(card.size());  //카드의 개수 중 랜덤으로 하나 뽑기
            nums[i] = card.get(num);        //num번째 카드를 뽑아 nums에 저장
            card.remove(num);  //num번째 카드를 삭제
        }
        //3번 방법
        /*
        for (int i =0; i<nums.length; i++){
            nums[i] = i+1;
        }
        for (int i =0; i<100; i++){
            int n1= rd.nextInt(nums.length);
            int n2= rd.nextInt(nums.length);

            int temp = nums[n1];
            nums[n1] = nums[n2];
            nums[n2] = temp;
        }


        */

        for (int i =0; i<nums.length; i++) {
            buttons[i].setText(nums[i] + "");

        } // 여기는 살아있어야해요~! 이부분이 버튼에 숫자를 적어주는 부분입니당 ㅎㅎ감사합니다 ㅎㅎ


        }//oncreate


    }
