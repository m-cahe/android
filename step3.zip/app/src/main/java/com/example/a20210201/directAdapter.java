package com.example.a20210201;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class directAdapter extends BaseAdapter {

    private Context co;
    private int layout;
    private ArrayList<String[]> data;
    private LayoutInflater inflater;
    
    //생성자 매서드 만들기 (alt+insert), Constructor
    //co, Layout, data선택 후 ok클릭

    public directAdapter(Context co, int layout, ArrayList<String[]> data) {
        this.co = co;
        this.layout = layout;
        this.data = data;
        this.inflater = (LayoutInflater) co.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                        //다운캐스팅(alt+enter)
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = inflater.inflate(layout, parent, false);
        }
        TextView tv = convertView.findViewById(R.id.tv_link);
        tv.setText(data.get(position)[0]);

        Button btn = convertView.findViewById(R.id.btn_link);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(data.get(position)[1]));
                co.startActivity(intent);
            }
        });



        return convertView;
    }
}
