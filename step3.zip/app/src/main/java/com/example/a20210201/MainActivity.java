package com.example.a20210201;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    Button btn_add;
    ListView lv;
    ArrayList<String[]> data = new ArrayList<>();
    directAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_add = findViewById(R.id.btn_add);
        lv = findViewById(R.id.listView);
        // 어허이~~~ lv findViewById를 안했네요~~~~

        String naver[] = {"naver", "http://naver.com"};
        String google[] = {"google", "https://www.google.co.kr"};
        String daum[] = {"daum", "https://www.daum.net"};
        String Youtube[] = {"Youtube", "https://www.youtube.com"};
//        data.add("네이버: https://www.naver.com/");
//        data.add("유튜브: https://www.youtube.com/?gl=KR");
//        data.add("다음: https://www.daum.net");
//        data.add("구글: https://www.google.co.kr/");
        data.add(naver);
        data.add(google);
        data.add(daum);
        data.add(Youtube);

        adapter = new directAdapter(MainActivity.this, R.layout.directlist, data);
        lv.setAdapter(adapter);

        /*********************/
        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SubActivity.class);
                startActivityForResult(intent, 0);
            }
        });
        //리스트뷰 안에 들어있는 textView나 button에 이벤트 주고 싶을때 -> Adaptert->getView!
        //리스트뷰 한 줄 통째에 이벤트 주고 싶을 때는 MainActivity -> listView!

        lv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                            //1.parent: 이벤트가 발생한 list그 자체
                            //2.view: 이벤트가 발생한 항목 view(세트 textview, Button세트)
                            //3.position: 이벤트가 발생한 인덱스 항목의 인덱스
                            //4.id : 이벤트가 발생한 항목의 id값(position과 같은 값)

                    //다이얼로그 띄우기
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    //context ->화면구성정보가 담긴 객체
                builder.setTitle("삭제하기");
                builder.setMessage("정말로 삭제하시겟습니까?");
                builder.setNegativeButton("cancel", null);  //nagativeButton: 왼쪽에 뜨는 버튼
                                                                        //취소버튼으로 활용. 아무일도 안 일어날거라서 두번째 매개변수 null
                //positiveButton(오른쪽에 뜨는 버튼)->ok버튼으로 활용
                builder.setPositiveButton("ok", new DialogInterface.OnClickListener() {     //버튼 온클릭리스너와 경로가 다름 new DialogInterface.OnClickListener
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        data.remove(position);
                        adapter.notifyDataSetChanged();
                    }
                });
                builder.create().show();
                return false;
                //return true였을 때 longclick과 일반click을 같이 쓸 수 없음(return false일때 같이 사용가능)
            }
        });



    }

        @Override
        protected void onActivityResult ( int requestCode, int resultCode, @Nullable Intent data){
            super.onActivityResult(requestCode, resultCode, data);
            //3번째 매개변수 Intent에서 url값 꺼내기

            if (resultCode == RESULT_OK){                  // 매개변수 데이터와 field변수 data를 구분하기 위해
                if (resultCode==0){
                    String url_addr = data.getStringExtra("url_addr");
                    String url_name = data.getStringExtra("url_name");
                    String add[] = {url_name,url_addr};
                    this.data.add(add);
                    adapter.notifyDataSetChanged();
                }
            }

        }


    }
