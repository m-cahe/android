package com.example.a20210201;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;

public class SubActivity extends AppCompatActivity {

    EditText url_addr;
    EditText url_name;
    Button btn_addUrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);

        url_addr = findViewById(R.id.url_addr);
        url_name = findViewById(R.id.url_name);
        btn_addUrl = findViewById(R.id.btn_add_url);

        //전송
        btn_addUrl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.putExtra("url_addr", url_addr.getText().toString());
                intent.putExtra("url_name", url_name.getText().toString());
                setResult(RESULT_OK, intent);
                finish();
            }
        });

    }
}